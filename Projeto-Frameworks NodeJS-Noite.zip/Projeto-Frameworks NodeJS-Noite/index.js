const express = require('express');
const { response } = require('express');
const app = express();

app.use(express.json())

app.get('/:CPF', (request, response) =>{
    
    const CPF = request.params.CPF
    let resultado
  
    resultado = CPF
        response.json({
        resultado,
    })
})
app.listen(8081, () => {
    console.log('servidor Rodando na porta 8081.')
})
